/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DECORARTOR;

/**
 *
 * @author Usuario
 */
public class DecoratorExample {
    public static void main(String[] args) {
        // Crear un café simple
        Coffee coffee = new SimpleCoffee();
        System.out.println("Costo: $" + coffee.cost() + ", Descripción: " + coffee.description());

        // Decorar el café con leche
        Coffee milkCoffee = new Milk(coffee);
        System.out.println("Costo: $" + milkCoffee.cost() + ", Descripción: " + milkCoffee.description());

        // Decorar el café con azúcar
        Coffee sugarCoffee = new Sugar(coffee);
        System.out.println("Costo: $" + sugarCoffee.cost() + ", Descripción: " + sugarCoffee.description());

        // Decorar el café con leche y azúcar
        Coffee milkSugarCoffee = new Sugar(new Milk(coffee));
        System.out.println("Costo: $" + milkSugarCoffee.cost() + ", Descripción: " + milkSugarCoffee.description());
    }
}