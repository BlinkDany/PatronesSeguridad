/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADAPTER;

/**
 *
 * @author Usuario
 */
public class Client {
    public static void main(String[] args) {
        // Utilizando el patrón Adapter para hacer que Adaptee sea compatible con Target
        Adaptee adaptee = new Adaptee();
        Target adapter = new Adapter(adaptee);

        // Llamada a request en Target, que internamente llama a specificRequest en Adaptee
        adapter.request();
    }
}