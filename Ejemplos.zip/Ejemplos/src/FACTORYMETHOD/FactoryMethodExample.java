/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FACTORYMETHOD;

/**
 *
 * @author Usuario
 */
public class FactoryMethodExample {
    public static void main(String[] args) {
        // Crear instancias de creadores concretos
        Creator creatorA = new ConcreteCreatorA();
        Creator creatorB = new ConcreteCreatorB();

        // Utilizar los métodos de fábrica para crear productos concretos
        Product productA = creatorA.factoryMethod();
        Product productB = creatorB.factoryMethod();

        // Realizar operaciones en los productos
        productA.doSomething();
        productB.doSomething();
    }
}