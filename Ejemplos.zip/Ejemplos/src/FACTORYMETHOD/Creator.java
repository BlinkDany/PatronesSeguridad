/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FACTORYMETHOD;

/**
 *
 * @author Usuario
 */
public abstract class Creator {
    // El método de fábrica abstracto que las subclases implementarán
    public abstract Product factoryMethod();

    // Otros métodos de la clase Creator (opcional)
    public void anOperation() {
        Product product = factoryMethod();
        product.doSomething();
    }
}