/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COMMAND;

/**
 *
 * @author Usuario
 */
public class CommandExample {
    public static void main(String[] args) {
        // Crear el dispositivo y los comandos
        Light light = new Light();
        Command lightOnCommand = new LightOnCommand(light);
        Command lightOffCommand = new LightOffCommand(light);

        // Configurar el control remoto con los comandos
        RemoteControl remote = new RemoteControl();
        remote.setCommand(lightOnCommand);

        // Presionar el botón para encender la luz
        remote.pressButton();

        // Configurar el control remoto con otro comando
        remote.setCommand(lightOffCommand);

        // Presionar el botón para apagar la luz
        remote.pressButton();
    }
}