/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABSTRACTFACTORY;

/**
 *
 * @author Usuario
 */
public class AbstractFactoryExample {
    public static void main(String[] args) {
        // Crear una fábrica para Windows
        AbstractFactory windowsFactory = new ConcreteFactoryWindows();

        // Crear productos específicos para Windows
        Button windowsButton = windowsFactory.createButton();
        Checkbox windowsCheckbox = windowsFactory.createCheckbox();

        // Pintar productos de Windows
        windowsButton.paint();
        windowsCheckbox.paint();

        // Crear una fábrica para MacOS
        AbstractFactory macosFactory = new ConcreteFactoryMacOS();

        // Crear productos específicos para MacOS
        Button macosButton = macosFactory.createButton();
        Checkbox macosCheckbox = macosFactory.createCheckbox();

        // Pintar productos de MacOS
        macosButton.paint();
        macosCheckbox.paint();
    }
}
