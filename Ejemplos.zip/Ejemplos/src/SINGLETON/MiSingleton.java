/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SINGLETON;

/**
 *
 * @author Usuario
 */
public class MiSingleton {
    // La instancia única de la clase
    private static MiSingleton instancia;

    // Constructor privado para evitar la creación de instancias desde fuera de la clase
    private MiSingleton() {
        // Código de inicialización si es necesario
    }

    // Método para obtener la instancia única de la clase
    public static MiSingleton obtenerInstancia() {
        // Si la instancia aún no ha sido creada, la crea
        if (instancia == null) {
            instancia = new MiSingleton();
        }
        // Devuelve la instancia única
        return instancia;
    }

    // Otros métodos y atributos de la clase
    public void metodoEjemplo() {
        System.out.println("¡Hola! Soy una instancia Singleton.");
    }
}