/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SINGLETON;

/**
 *
 * @author Usuario
 */
public class EjemploUsoSingleton {
    public static void main(String[] args) {
        // Obtén la instancia única de MiSingleton
        MiSingleton instancia = MiSingleton.obtenerInstancia();

        // Usa la instancia
        instancia.metodoEjemplo();
    }
}