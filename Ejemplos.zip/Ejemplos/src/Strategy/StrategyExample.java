/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strategy;

/**
 *
 * @author Usuario
 */
public class StrategyExample {
    public static void main(String[] args) {
        // Crear instancias de estrategias
        Strategy strategyA = new ConcreteStrategyA();
        Strategy strategyB = new ConcreteStrategyB();

        // Crear contexto con una estrategia inicial
        Context context = new Context(strategyA);

        // Ejecutar la estrategia actual
        context.executeStrategy();

        // Cambiar la estrategia en tiempo de ejecución
        context.setStrategy(strategyB);

        // Ejecutar la nueva estrategia
        context.executeStrategy();
    }
}