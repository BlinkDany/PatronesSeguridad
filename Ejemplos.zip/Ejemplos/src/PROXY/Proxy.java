/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROXY;

/**
 *
 * @author Usuario
 */
public class Proxy implements Subject {
    private RealSubjectImpl realSubject;

    @Override
    public void request() {
        if (realSubject == null) {
            realSubject = new RealSubjectImpl();
        }
        System.out.println("Proxy: Verificación antes de realizar la solicitud.");
        realSubject.request();
        System.out.println("Proxy: Postprocesamiento después de la solicitud.");
    }
}
