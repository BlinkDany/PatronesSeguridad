/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OBSERVER;

/**
 *
 * @author Usuario
 */
public class ObserverExample {
    public static void main(String[] args) {
        // Crear un sujeto observado
        ConcreteSubject subject = new ConcreteSubject();

        // Crear observadores y agregarlos al sujeto
        ConcreteObserver observer1 = new ConcreteObserver(subject);
        ConcreteObserver observer2 = new ConcreteObserver(subject);

        // Cambiar el estado del sujeto y notificar a los observadores
        subject.setState(1);

        // Resultado esperado: Los dos observadores deben imprimir "El estado ha cambiado: 1"
    }
}